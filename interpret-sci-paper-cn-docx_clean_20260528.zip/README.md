# 慢老师解读文献技能

这是一个 Codex 技能，用于把科学论文 PDF、DOI、本地路径或论文链接转换为中文深度解读 Word 文档。输出风格面向科研公众号长文，包含证据链、图表逐图解读、写作结构拆解、方法 SOP、批判性评价，以及最后的一页式“文献内化卡片”。

## 功能亮点

- 自动按 14 节结构组织文献解读
- 支持插入论文主图并在对应位置逐图解读
- 强制生成最终的“文献内化卡片”
- Word 渲染脚本会把内化卡片排成手绘卡片风格
- 内置 Springer Nature 图像下载辅助脚本

## 仓库结构

```text
.
├── SKILL.md
├── agents/
│   └── openai.yaml
├── references/
│   └── article-interpretation-format.md
├── scripts/
│   ├── download_springer_nature_figures.py
│   └── render_cn_interpretation_docx.py
├── requirements.txt
└── README.md
```

## 使用方式

将整个目录放入 Codex 技能目录，或在 Codex 中显式引用本目录作为技能。触发方式包括：

- 上传或提供论文 PDF
- 提供 DOI 或论文 URL
- 请求“文献解读”“论文精读”“公众号风格解读”
- 请求生成 Word/DOCX
- 请求生成“文献内化卡片”

默认产物是 `.docx`，草稿建议先写成 Markdown，再用脚本渲染：

```bash
python scripts/render_cn_interpretation_docx.py input.md output.docx
```

## 文献内化卡片

最终章节固定为：

```markdown
## 14. 文献内化卡片

文献标题：...
一句话故事：...
核心科学问题：...
关键机制链：...
最关键的三张图：...
最强证据：...
最大漏洞：...
可迁移价值：...
可借鉴表达：...
```

卡片强调把文献从“读懂”推进到“能复盘、能迁移、能变成自己的科研表达素材”。

## 依赖

渲染 Word 需要：

```bash
pip install -r requirements.txt
```

## 注意事项

- 仓库不包含论文 PDF、已生成解读文档或版权图像素材。
- 使用论文原图时，请遵守对应论文和出版社的版权许可。
- 生成内容应基于论文证据，不应编造实验数据或机制结论。
